fix_js1 = localStorage["fix_js1"];
if (fix_js1 != null && fix_js1 != 'null' && fix_js1 != 'undefined' && fix_js1 != ' ' && fix_js1 != undefined){
	$('body').append(fix_js1);
}

fix_js2 = localStorage["fix_js2"];
if (fix_js2 != null && fix_js2 != 'null' && fix_js2 != 'undefined' && fix_js2 != ' ' && fix_js2 != undefined){
	$('body').append(fix_js2);
}